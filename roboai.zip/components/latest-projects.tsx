"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Clock, Users, BookOpen } from "lucide-react"

export default function LatestProjects({ projects }) {
  const getDifficultyText = (difficulty: string) => {
    return difficulty === "beginner" ? "Boshlang'ich" : 
           difficulty === "intermediate" ? "O'rta" : 
           "Yuqori"
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">So'nggi loyihalar</h2>
        <Button variant="outline" asChild>
          <Link href="/projects">Barcha loyihalar</Link>
        </Button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {projects.map((project) => (
          <Card key={project.id}>
            <CardHeader>
              <CardTitle>{project.title}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">{project.summary}</p>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  <span>{project.estimated_time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-primary" />
                  <span>{project.max_participants} o'quvchi</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-primary" />
                  <span>{getDifficultyText(project.difficulty)}</span>
                </div>
              </div>
              <Button className="w-full" asChild>
                <Link href={`/projects/${project.id}`}>Loyihani boshlash</Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

