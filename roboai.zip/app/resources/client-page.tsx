"use client"

import { useState, useEffect } from "react"
import { useLanguage } from "@/components/language-provider"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { AlertCircle } from "lucide-react"

interface Resource {
  id: number;
  title: string;
  description: string;
  content: string;
  image: string;
  category: string;
  file: string;
  external_link: string;
  is_external: boolean;
  is_downloadable: boolean;
  created_at: string;
  updated_at: string;
}

interface ClientResourcesPageProps {
  initialResources: Resource[];
}

export default function ClientResourcesPage({ initialResources }: ClientResourcesPageProps) {
  const { t } = useLanguage()
  const [resources, setResources] = useState<Resource[]>([])

  useEffect(() => {
    // Validate and set resources
    if (initialResources && Array.isArray(initialResources)) {
      const validatedResources = initialResources.map(resource => ({
        id: resource.id || 0,
        title: resource.title || 'Resurs',
        description: resource.description || '',
        content: resource.content || '',
        image: resource.image || '/placeholder.svg',
        category: resource.category || 'darsliklar',
        file: resource.file || '',
        external_link: resource.external_link || '',
        is_external: resource.is_external || false,
        is_downloadable: resource.is_downloadable || false,
        created_at: resource.created_at || new Date().toISOString(),
        updated_at: resource.updated_at || new Date().toISOString()
      }))
      setResources(validatedResources)
    }
  }, [initialResources])

  const resourceCategories = [
    { id: "all", name: "Barcha resurslar" },
    { id: "darsliklar", name: "Darsliklar" },
    { id: "video", name: "Video darslar" },
    { id: "kitoblar", name: "Kitoblar" },
  ]

  const filterByCategory = (category: string) => {
    if (!resources || resources.length === 0) {
      return []
    }

    if (category === "all") {
      return resources
    }

    return resources.filter((resource) => {
      if (!resource.category) {
        return false
      }
      return resource.category.toLowerCase() === category.toLowerCase()
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8 md:py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">{t('resources')}</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              {t('resourceDescription')}
            </p>
          </div>

          {resources.length === 0 ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-100 text-amber-600 mb-4">
                <AlertCircle className="h-6 w-6" />
              </div>
              <h2 className="text-xl font-medium mb-2">{t('noResourcesAvailable')}</h2>
              <p className="text-muted-foreground">
                {t('checkBackLater')}
              </p>
            </div>
          ) : (
            <>
              <Tabs defaultValue="all" className="mb-12">
                <TabsList className="grid w-full grid-cols-4 mb-8">
                  {resourceCategories.map((category) => (
                    <TabsTrigger key={category.id} value={category.id}>
                      {category.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
                {resourceCategories.map((category) => (
                  <TabsContent key={category.id} value={category.id}>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {filterByCategory(category.id).map((resource) => (
                        <Card key={resource.id} className="overflow-hidden">
                          <div className="relative h-48">
                            <Image
                              src={resource.image}
                              alt={resource.title}
                              fill
                              className="object-cover"
                              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                              priority={false}
                            />
                          </div>
                          <CardHeader>
                            <CardTitle>{resource.title}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-muted-foreground mb-4">
                              {resource.description}
                            </p>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <span className="inline-block px-2 py-1 rounded-full bg-primary/10 text-primary">
                                {resource.category}
                              </span>
                            </div>
                          </CardContent>
                          <CardFooter>
                            <Button asChild className="w-full">
                              <Link href={`/resources/${resource.id}`}>
                                {t('download')}
                              </Link>
                            </Button>
                          </CardFooter>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}

