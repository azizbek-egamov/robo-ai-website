"use client"

import { createContext, useContext, useState, ReactNode } from "react"

interface LanguageContextType {
  language: string;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

const translations = {
  // Hero Section
  heroTitle: "Robototexnika va Sun'iy Intellekt",
  heroSubtitle: "Kelajak texnologiyalarini o'rganing va loyihalarni amalga oshiring",
  getStarted: "Boshlash",
  learnMore: "Batafsil",

  // Contact Page
  contactTitle: "Biz bilan bog'laning",
  contactDescription: "Savollaringiz yoki takliflaringiz bo'lsa, bizga yozing",
  contactForm: "Xabar yuborish",
  name: "Ism",
  message: "Xabar",
  send: "Yuborish",
  sending: "Yuborilmoqda...",
  messageSent: "Xabaringiz muvaffaqiyatli yuborildi",
  errorSending: "Xabar yuborishda xatolik yuz berdi",
  map: "Xarita",
  workingHours: "Ish vaqti",
  workingDays: "Dushanbadan Jumagacha",
  contactInfo: "Aloqa ma'lumotlari",
  address: "Manzil",
  phone: "Telefon",
  email: "Elektron pochta",

  // Featured Section
  featuredCourses: "Tanlangan kurslar",
  viewAll: "Barchasini ko'rish",

  // Company Info
  company: "Robo AI",
  companyDescription: "Robototexnika va sun'iy intellekt bo'yicha yetakchi ta'lim platformasi",

  // Legal
  privacy: "Maxfiylik",
  privacyPolicy: "Maxfiylik siyosati",
  termsOfService: "Xizmat shartlari",
  allRightsReserved: "Barcha huquqlar himoyalangan",

  // Navbar
  home: "Bosh sahifa",
  courses: "Kurslar",
  projects: "Loyihalar",
  resources: "Resurslar",
  news: "Yangiliklar",
  contact: "Aloqa",
  about: "Biz haqimizda",
  login: "Kirish",
  register: "Ro'yxatdan o'tish",
  logout: "Chiqish",

  // Footer
  socialMedia: "Ijtimoiy tarmoqlar",
  quickLinks: "Tezkor havolalar",
  copyright: "Barcha huquqlar himoyalangan",

  // Courses
  courseDescription: "Robototexnika va sun'iy intellekt bo'yicha kurslarimiz bilan tanishing",
  enrollNow: "Ro'yxatdan o'tish",
  noCoursesAvailable: "Kurslar mavjud emas",
  checkBackLater: "Iltimos, keyinroq tekshiring",
  errorLoadingCourses: "Kurslarni yuklashda xatolik yuz berdi",

  // Projects
  projectDescription: "Robototexnika va sun'iy intellekt bo'yicha loyihalarimiz bilan tanishing",
  viewProject: "Loyihani ko'rish",
  noProjectsAvailable: "Loyihalar mavjud emas",
  errorLoadingProjects: "Loyihalarni yuklashda xatolik yuz berdi",

  // Resources
  resourceDescription: "Robototexnika va sun'iy intellekt bo'yicha resurslarimiz bilan tanishing",
  download: "Yuklab olish",
  noResourcesAvailable: "Resurslar mavjud emas",
  errorLoadingResources: "Resurslarni yuklashda xatolik yuz berdi",

  // News
  newsDescription: "Robototexnika va sun'iy intellekt bo'yicha yangiliklarimiz bilan tanishing",
  readMore: "Batafsil",
  noNewsAvailable: "Yangiliklar mavjud emas",
  errorLoadingNews: "Yangiliklarni yuklashda xatolik yuz berdi",

  // Tests
  tests: "Testlar",
  takeTest: "Testni boshlash", 
  testsDescription: "Bilimlaringizni testlar orqali sinab ko'ring",
  startTest: "Testni boshlash",
  noTestsAvailable: "Testlar mavjud emas",
  errorLoadingTests: "Testlarni yuklashda xatolik yuz berdi",

  // Common
  loading: "Yuklanmoqda...",
  error: "Xatolik yuz berdi",
  retry: "Qayta urinish",
  backToHome: "Bosh sahifaga qaytish",
  notFound: "Sahifa topilmadi",
  serverError: "Server xatosi",
  apiError: "API xatosi",
  networkError: "Internet aloqasi xatosi",
  unknownError: "Noma'lum xatolik",
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language] = useState("uz")

  const t = (key: string): string => {
    return translations[key as keyof typeof translations] || key
  }

  return (
    <LanguageContext.Provider value={{ language, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

