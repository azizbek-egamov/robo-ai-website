"use client"

import { useLanguage } from "@/components/language-provider"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BellIcon as BrandTelegram } from "lucide-react"
import { useState, useEffect } from "react"

export default function NewsSidebar({ news }) {
  const { t, language } = useLanguage()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const formatDate = (dateString: string) => {
    return new Intl.DateTimeFormat("uz-UZ", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date(dateString))
  }

  if (!news || news.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Yangiliklar</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Hozircha yangiliklar mavjud emas.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Yangiliklar</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {news.map((item) => (
          <div key={item.id} className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{formatDate(item.date)}</span>
            </div>
            <h3 className="font-medium">{item.title}</h3>
            <p className="text-sm text-muted-foreground">{item.summary}</p>
            <Button variant="link" className="p-0 h-auto" asChild>
              <Link href={`/news/${item.id}`}>Batafsil</Link>
            </Button>
          </div>
        ))}
      </CardContent>
      <CardFooter>
        <Button variant="outline" className="w-full" asChild>
          <Link href="/news">Barcha yangiliklar</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

