"use client"

import { useState, useEffect } from "react"
import { useLanguage } from "@/components/language-provider"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { AlertCircle } from "lucide-react"

interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  difficulty: string;
  materials: {
    id: number;
    title: string;
    description: string;
    quantity: number;
    unit: string;
  }[];
  steps: {
    id: number;
    step_number: number;
    title: string;
    description: string;
    image: string;
  }[];
  created_at: string;
  updated_at: string;
}

interface ClientProjectsPageProps {
  initialProjects: Project[];
}

export default function ClientProjectsPage({ initialProjects }: ClientProjectsPageProps) {
  const { t } = useLanguage()
  const [projects, setProjects] = useState<Project[]>([])

  useEffect(() => {
    // Validate and set projects
    if (initialProjects && Array.isArray(initialProjects)) {
      const validatedProjects = initialProjects.map(project => ({
        id: project.id || 0,
        title: project.title || 'Loyiha',
        description: project.description || '',
        image: project.image || '/placeholder.svg',
        difficulty: project.difficulty || 'boshlang\'ich',
        materials: (project.materials || []).map(material => ({
          id: material.id || 0,
          title: material.title || '',
          description: material.description || '',
          quantity: material.quantity || 0,
          unit: material.unit || ''
        })),
        steps: (project.steps || []).map(step => ({
          id: step.id || 0,
          step_number: step.step_number || 0,
          title: step.title || '',
          description: step.description || '',
          image: step.image || '/placeholder.svg'
        })),
        created_at: project.created_at || new Date().toISOString(),
        updated_at: project.updated_at || new Date().toISOString()
      }))
      setProjects(validatedProjects)
    }
  }, [initialProjects])

  const projectCategories = [
    { id: "all", name: "Barcha loyihalar" },
    { id: "boshlang'ich", name: "Boshlang'ich" },
    { id: "o'rta", name: "O'rta" },
    { id: "yuqori", name: "Yuqori" },
  ]

  const filterByCategory = (category: string) => {
    if (!projects || projects.length === 0) {
      return []
    }

    if (category === "all") {
      return projects
    }

    return projects.filter((project) => {
      if (!project.difficulty) {
        return false
      }
      return project.difficulty.toLowerCase() === category.toLowerCase()
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8 md:py-12">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">{t('projects')}</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              {t('projectDescription')}
            </p>
          </div>

          {projects.length === 0 ? (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-amber-100 text-amber-600 mb-4">
                <AlertCircle className="h-6 w-6" />
              </div>
              <h2 className="text-xl font-medium mb-2">{t('noProjectsAvailable')}</h2>
              <p className="text-muted-foreground">
                {t('checkBackLater')}
              </p>
            </div>
          ) : (
            <>
              <Tabs defaultValue="all" className="mb-12">
                <TabsList className="grid w-full grid-cols-4 mb-8">
                  {projectCategories.map((category) => (
                    <TabsTrigger key={category.id} value={category.id}>
                      {category.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
                {projectCategories.map((category) => (
                  <TabsContent key={category.id} value={category.id}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {filterByCategory(category.id).map((project) => (
                        <Card key={project.id} className="overflow-hidden">
                          <div className="relative h-48">
                            <Image
                              src={project.image}
                              alt={project.title}
                              fill
                              className="object-cover"
                              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                              priority={false}
                            />
                          </div>
                          <CardHeader>
                            <CardTitle>{project.title}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-muted-foreground mb-4">
                              {project.description}
                            </p>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <span className="inline-block px-2 py-1 rounded-full bg-primary/10 text-primary">
                                {project.difficulty}
                              </span>
                            </div>
                          </CardContent>
                          <CardFooter>
                            <Button asChild className="w-full">
                              <Link href={`/projects/${project.id}`}>
                                {t('viewProject')}
                              </Link>
                            </Button>
                          </CardFooter>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}

