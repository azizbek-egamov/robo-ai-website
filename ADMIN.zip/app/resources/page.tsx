"use client"

import { useState, useEffect } from "react"
import { fetchResources } from "@/lib/api"
import ClientResourcesPage from "./client-page"
import ApiConnectionError from "@/components/api-connection-error"
import { Skeleton } from "@/components/ui/skeleton"

interface Resource {
  id: number;
  title: string;
  description: string;
  content: string;
  image: string;
  category: string;
  file: string;
  external_link: string;
  is_external: boolean;
  is_downloadable: boolean;
  created_at: string;
  updated_at: string;
}

interface ApiResponse {
  results?: Resource[];
  resources?: Resource[];
  [key: string]: any;
}

export default function ResourcesPage() {
  const [resources, setResources] = useState<Resource[]>([])
  const [hasError, setHasError] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const fetchData = async () => {
    setIsLoading(true)
    setHasError(false)

    try {
      const resourcesData = await fetchResources() as ApiResponse
      
      if (!resourcesData) {
        throw new Error('No data received from server')
      }

      let resourcesArray: Resource[] = []
      
      if (Array.isArray(resourcesData)) {
        resourcesArray = resourcesData
      } else if (resourcesData.results) {
        resourcesArray = resourcesData.results
      } else if (resourcesData.resources) {
        resourcesArray = resourcesData.resources
      } else {
        resourcesArray = Object.values(resourcesData)
      }

      if (!Array.isArray(resourcesArray)) {
        throw new Error('Invalid data format received from server')
      }

      // Validate and clean the data
      const validatedResources = resourcesArray.map(resource => ({
        id: resource.id || 0,
        title: resource.title || 'Resurs',
        description: resource.description || '',
        content: resource.content || '',
        image: resource.image || '/placeholder.svg',
        category: resource.category || 'darsliklar',
        file: resource.file || '',
        external_link: resource.external_link || '',
        is_external: resource.is_external || false,
        is_downloadable: resource.is_downloadable || false,
        created_at: resource.created_at || new Date().toISOString(),
        updated_at: resource.updated_at || new Date().toISOString()
      }))

      setResources(validatedResources)
    } catch (error) {
      console.error("Error fetching resources:", error)
      setHasError(true)
      setResources([])
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [])

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <main className="flex-1">
          <div className="container mx-auto px-4 py-8">
            <div className="space-y-4">
              <Skeleton className="h-12 w-3/4 mx-auto" />
              <Skeleton className="h-6 w-1/2 mx-auto" />
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="space-y-4">
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-8 w-3/4" />
                    <Skeleton className="h-20 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1">
        {hasError ? (
          <ApiConnectionError onRetry={fetchData} />
        ) : (
          <ClientResourcesPage initialResources={resources} />
        )}
      </main>
    </div>
  )
}

